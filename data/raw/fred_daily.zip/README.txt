----------------------------------------------------------------
FRED Graph Observations
Federal Reserve Economic Data, Federal Reserve Bank of St. Louis
Link: https://fred.stlouisfed.org
Help: https://fredhelp.stlouisfed.org
This data may be copyrighted. Please refer to the Terms of Use:
https://fred.stlouisfed.org/legal#fred-terms-faq
File Created: 2026-11-04 12:11 am CST
----------------------------------------------------------------

------  ----------------------------------------------------------------------  ------------------------
DGS2    Market Yield on U.S. Treasury Securities at 2-Year Constant Maturity,   Data Updated: 2026-11-03
        Quoted on an Investment Basis, Percent, Daily, Not Seasonally Adjusted
DGS10   Market Yield on U.S. Treasury Securities at 10-Year Constant Maturity,  Data Updated: 2026-11-03
        Quoted on an Investment Basis, Percent, Daily, Not Seasonally Adjusted
VIXCLS  CBOE Volatility Index: VIX, Index, Daily, Not Seasonally Adjusted       Data Updated: 2026-11-03
------  ----------------------------------------------------------------------  ------------------------

